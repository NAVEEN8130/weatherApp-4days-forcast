import { useState } from "react";
import "./head.css"

const Header = () => {

      let [city, setCity] = useState("");
      let [latitude, setLatitude] = useState("")
      let [longitude, setLongitude] = useState("")
      let [dmsCord, setDmsCord] = useState("")

      const citySetter = (e) => {
            setCity(e.target.value);
      }

      function decimalToDMS(decimal) {
            const degrees = Math.floor(decimal);
            const minutesDecimal = (decimal - degrees) * 60;
            const minutes = Math.floor(minutesDecimal);
            const seconds = Math.floor(((minutesDecimal - minutes) * 60));
            return `${degrees}° ${minutes}' ${seconds}''`
      }

      const getWeatherData = async (city) => {

            let url = `http://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=158c940851fb4465d10f9b8c94149ce1`
            let response = await fetch(url)
            let data = await response.json();
            console.log('data: ', data);

            // DMS string
            let latitudeDMS = decimalToDMS(data[0].lat)
            let longitudeDMS = decimalToDMS(data[0].lon)
            let coordinatesDMS = `${latitudeDMS} ${longitudeDMS}`
            setDmsCord(coordinatesDMS)

            // lat, lon setters
            setLatitude(data[0].lat)
            setLongitude(data[0].lon)

            let url2 = `api.openweathermap.org/data/2.5/forecast?lat=${(data[0].lat)}&lon=${data[0].lon}&appid=158c940851fb4465d10f9b8c94149ce1`
            console.log('url2: ', url2);
            let response2 = await fetch(url2)
            console.log('response2: ', response2);
            let data2 = await response2.json();
            console.log(data2);
      }


      return (
            <div className="container">
                  <div className="description">
                        <p className="placename"><i class="fa-solid fa-location-dot"></i>{city}</p>
                        <p>{dmsCord}</p>
                  </div>
                  <div className="searchbar">
                        <input className="input" id="cityname" onChange={citySetter} type="text" placeholder="Search your city" />
                        <button className="icon" onClick={() => getWeatherData(city)}><i class="fa-solid fa-magnifying-glass"></i></button>
                        <hr />
                  </div>
            </div>
      )
}
export default Header